const express = require("express");
const router = express.Router();

// DB 연결부 ===================================
// const connectDB = require("../config/connectDB.js");
// const db = connectDB.init();
// // connectDB.open(db);
//=============================================

//============================================

//=========================================

module.exports = router;
